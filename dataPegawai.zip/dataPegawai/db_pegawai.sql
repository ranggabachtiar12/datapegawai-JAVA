
DROP TABLE IF EXISTS `data_pegawai`;
CREATE TABLE IF NOT EXISTS `data_pegawai` (
  `ID`   varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jenis_kelamin`        varchar(20) NOT NULL,
  PRIMARY KEY (`kode_barang`)
);
